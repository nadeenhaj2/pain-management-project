const rawBaseUrl = import.meta.env.VITE_API_URL || "/api";

export const API_BASE_URL = rawBaseUrl.replace(/\/$/, "");

export function apiUrl(path = "") {
  const cleanPath = String(path).replace(/^\//, "");
  return cleanPath ? `${API_BASE_URL}/${cleanPath}` : API_BASE_URL;
}
