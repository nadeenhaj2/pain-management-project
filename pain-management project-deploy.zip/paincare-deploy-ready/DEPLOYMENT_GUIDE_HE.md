# מדריך פריסה לפרויקט PainCare Assistant

הפרויקט מוכן לפריסה ללא localhost:

- Frontend: תיקיית `paincare-assistant` ל־Vercel
- Backend: תיקיית `server` ל־Render
- Database: MongoDB Atlas

## 1. MongoDB Atlas

צרו Cluster ב־MongoDB Atlas וקחו connection string.
ב־Render שימו אותו כמשתנה סביבה בשם:

```text
MONGO_URI=mongodb+srv://USERNAME:PASSWORD@cluster0.xxxxx.mongodb.net/paincare_assistant
```

## 2. Render - Backend

פתחו Render > New > Web Service וחברו את GitHub.

הגדרות:

```text
Root Directory: server
Build Command: npm install
Start Command: npm start
```

Environment Variables ב־Render:

```text
MONGO_URI=your MongoDB Atlas connection string
GEMINI_API_KEY=your Gemini API key
GEMINI_MODEL=gemini-3.1-flash-lite
CLIENT_ORIGIN=https://your-frontend-name.vercel.app
```

אחרי הפריסה בדקו בדפדפן:

```text
https://your-backend-name.onrender.com/api/health
```

אם מתקבל `Server is working`, השרת עובד.

## 3. Vercel - Frontend

פתחו Vercel > New Project וחברו את GitHub.

הגדרות:

```text
Root Directory: paincare-assistant
Framework Preset: Vite
Build Command: npm run build
Output Directory: dist
```

Environment Variable ב־Vercel:

```text
VITE_API_URL=https://your-backend-name.onrender.com/api
```

## 4. חשוב מאוד

לא שולחים למרצה קישור של localhost.
שולחים את קישור Vercel, למשל:

```text
https://your-project.vercel.app
```

אם אחרי יצירת Vercel אתם יודעים את כתובת האתר, עדכנו ב־Render את:

```text
CLIENT_ORIGIN=https://your-project.vercel.app
```
